<?php
namespace cetos\page;
use wcf\page\AbstractPage;


class IndexPage extends AbstractPage { 

public $activeMenuItem = 'ccetos.header.menu.consulting';


}
