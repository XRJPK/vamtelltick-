<?php
namespace cetos\page;
use wcf\page\AbstractPage;


class ConsultingPage extends AbstractPage { 

public $activeMenuItem = 'ccetos.header.menu.consulting';


}
