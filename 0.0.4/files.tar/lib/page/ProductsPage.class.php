<?php
namespace cetos\page;
use wcf\page\AbstractPage;


class ProductsPage extends AbstractPage { 

public $activeMenuItem = 'cetos.header.menu.products';


}
