<?php
namespace cetos\page;
use wcf\page\AbstractPage;


class SoPacPage extends AbstractPage { 

public $activeMenuItem = 'cetos.header.menu.products';


}
