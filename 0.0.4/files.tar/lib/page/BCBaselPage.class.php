<?php
namespace cetos\page;
use wcf\page\AbstractPage;


class BCBaselPage extends AbstractPage { 

public $activeMenuItem = 'cetos.header.menu.jobs';


}
