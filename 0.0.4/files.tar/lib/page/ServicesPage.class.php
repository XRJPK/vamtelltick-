<?php
namespace cetos\page;
use wcf\page\AbstractPage;


class ServicesPage extends AbstractPage { 

public $activeMenuItem = 'cetos.header.menu.services';


}
