<?php
namespace cetos\page;
use wcf\page\AbstractPage;


class SoSMIPage extends AbstractPage { 

public $activeMenuItem = 'cetos.header.menu.products';


}
