<?php
namespace cetos\page;
use wcf\page\AbstractPage;


class JobsPage extends AbstractPage { 

public $activeMenuItem = 'cetos.header.menu.jobs';


}
