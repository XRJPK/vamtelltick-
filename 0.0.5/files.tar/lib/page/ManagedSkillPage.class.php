<?php
namespace cetos\page;
use wcf\page\AbstractPage;


class ManagedSkillPage extends AbstractPage { 

public $activeMenuItem = 'cetos.header.menu.consulting';


}
