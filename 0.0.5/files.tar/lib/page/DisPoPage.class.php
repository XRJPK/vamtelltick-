<?php
namespace cetos\page;
use wcf\page\AbstractPage;


class DisPoPage extends AbstractPage { 

public $activeMenuItem = 'cetos.header.menu.products';


}
