<?php
namespace cetos\page;
use wcf\page\AbstractPage;


class DigitalMediaPage extends AbstractPage { 

public $activeMenuItem = 'cetos.header.menu.systems';


}
