<?php
namespace cetos\page;
use wcf\page\AbstractPage;


class SoftwareEngineeringPage extends AbstractPage { 

public $activeMenuItem = 'cetos.header.menu.systems';


}
