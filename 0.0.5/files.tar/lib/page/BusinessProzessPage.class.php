<?php
namespace cetos\page;
use wcf\page\AbstractPage;


class BusinessProzessPage extends AbstractPage { 

public $activeMenuItem = 'cetos.header.menu.consulting';


}
