<?php
namespace cetos\page;
use wcf\page\AbstractPage;


class EPLPage extends AbstractPage { 

public $activeMenuItem = 'cetos.header.menu.products';


}
