<?php
namespace cetos\page;
use wcf\page\AbstractPage;


class ReferencesPage extends AbstractPage { 

public $activeMenuItem = 'cetos.header.menu.references';


}
