<?php
/**
 * @author Sebastian Heldt
 * @copyright 2014 Sebastian Heldt
 * @license	
 * @package	de.getpoint.getpoint
 */
// include config
require_once(__DIR__.'/config.inc.php');

// include wcf
require_once(RELATIVE_WCF_DIR.'global.php');
